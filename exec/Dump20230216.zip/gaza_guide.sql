-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8c207.p.ssafy.io    Database: gaza
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `guide`
--

DROP TABLE IF EXISTS `guide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guide` (
  `guide_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `oneline_introduction` varchar(50) DEFAULT NULL,
  `introduction` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `close_time_start` time DEFAULT NULL,
  `close_time_end` time DEFAULT NULL,
  `price` int DEFAULT NULL,
  `license` tinyint DEFAULT '0',
  PRIMARY KEY (`guide_id`),
  KEY `FK_user_TO_guide_1` (`user_id`),
  CONSTRAINT `FK_user_TO_guide_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guide`
--

LOCK TABLES `guide` WRITE;
/*!40000 ALTER TABLE `guide` DISABLE KEYS */;
INSERT INTO `guide` VALUES (1,5,'경주의 공주 프린세스 안나 ^^','안녕하세요! 경주의 공주 프린세스 안나입니다! 여러분을 신라왕국의 깊은 곳 까지 안내해 드릴께요! 많이 오세요.','7333befe-5a32-4853-ba06-50ec2aa18794_guide4.jpg','대한민국','경주',NULL,NULL,10000,0),(2,4,'최고의 만족을 선사하는 가이드입니다','안녕하세요. 대한민국 광주 가이드합니다. ~~ ','751aa0ff-4b4b-408a-a1c4-6f940b78a80e_guide1.png','대한민국','광주',NULL,NULL,12000,0),(3,3,NULL,'안녕하세요. 제주도에서 30년을 산 김석필입니다.\n맛있는 해산물, 재밌는 액티비티, 귤 농장 체험까지 모두 즐길 수 있게 해드리겠습니다.\n제주도의 아름다운 풍경 보러오세요.','75b0ffaa-eb10-4f01-b812-226494aa12ae_guide2.png','대한민국','제주도',NULL,NULL,20000,0),(4,7,'아름다운 거제도로 오세요.','아름다운 거제도로 오세요!! 정말 아름다워요.','04d2c093-10be-484b-89b0-4f3a9f1eb1ec_guide3.jpg','대한민국','거제도',NULL,NULL,15000,0),(5,8,'부산 가이드 사쿠라입니다.','안녕하세요! 여러분의 여행가이드 사쿠라입니다! 여러분의 여행을 편하게 만들어 드릴께요!','a7f72409-bd54-4bef-8812-0e0eedf2d56a_guide5.png','대한민국','부산',NULL,NULL,10000,0),(6,6,'서울 궁 나들이해요','서울에서 오래 산 김지성입니다. 저만 믿어주세요. 서울 구석구석 궁보러 들어갑니다.','66c59875-d620-4ce6-a67c-68251b3f7e1c_guide34.png','대한민국','서울',NULL,NULL,12000,0);
/*!40000 ALTER TABLE `guide` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-16 16:04:20
