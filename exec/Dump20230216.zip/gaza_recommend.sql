-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8c207.p.ssafy.io    Database: gaza
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recommend`
--

DROP TABLE IF EXISTS `recommend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommend` (
  `recommend_id` int NOT NULL AUTO_INCREMENT,
  `guide_id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `category_code` varchar(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `latitude` decimal(10,0) DEFAULT NULL,
  `longitude` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`recommend_id`),
  KEY `FK_guide_TO_recommend_1` (`guide_id`),
  CONSTRAINT `FK_guide_TO_recommend_1` FOREIGN KEY (`guide_id`) REFERENCES `guide` (`guide_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommend`
--

LOCK TABLES `recommend` WRITE;
/*!40000 ALTER TABLE `recommend` DISABLE KEYS */;
INSERT INTO `recommend` VALUES (1,5,'이씨할매횟집','부산 해운대구 달맞이길62번길 46','LO01','d9fafcec-cf92-47a4-b747-935037509618_4716d40d-32af-4313-aabb-1e37e4754f61.avif',NULL,NULL),(2,2,'분식집','광주 동구 동계천로 143-5 1층 분식집','LO01','43cb71fe-99e2-489a-b622-e4c43a4cd836_광주_동명동_분식집.jpg',NULL,NULL),(3,3,'한라산','제주 서귀포시 토평동 산15-1','LO02','241941ef-04cc-42d4-9e1c-b8729a3a4fdb_한라산.png',NULL,NULL),(4,2,'광주 패밀리랜드','광주 북구 우치로 677 광주패밀리랜드','LO05','62e24a49-33c1-43a7-b55f-554735369b16_광주 패밀리랜드_복사.jpg',NULL,NULL),(5,3,'사계해수욕장','제주 서귀포시 안덕면 사계리','LO05','870176df-6f07-459c-b310-e734d91a707c_사계해수욕장.jpg',NULL,NULL),(6,3,'형제섬','제주 서귀포시 안덕면 사계리 산44','LO02','4216f3a9-9350-45d2-b6e9-205d2977abe9_형제섬.jpg',NULL,NULL),(7,2,'소바 쿄다이','광주 동구 동계천로 135-3 소바 쿄다이','LO01','7d264e38-5758-48b4-8327-470db920b8cd_광주_동명동_소바쿄다이_01.jpg',NULL,NULL),(8,1,'양동마을','경북 경주시 강동면 양동리 125','LO05','f0b514ea-a8e8-42f6-b958-c3da28c75e14_양동마을.jpg',NULL,NULL),(9,2,'광주 펭귄마을','광주 남구 천변좌로446번길 7','LO02','b94ac313-39d1-437e-8e2a-839cd46318cc_광주 펭귄마을_복사본.jpg',NULL,NULL),(10,1,'민속공예촌','경주시 보불로 230','LO05','8e7e4c1f-e406-4e4d-8ffd-dbe42d30965e_민속공예촌.png',NULL,NULL),(11,2,'광주 주디마리','광주 북구 우치로 86 지하1층','LO01','bce86da5-6e0d-43b3-922d-18bfa2656294_광주_주디마리_ㅂ고.jpg',NULL,NULL),(12,1,'북천 수변산책로 코스','경주시 용담로 79-41, 황성공원','LO02','91db9541-52e7-4400-bd98-c3315407cbae_북천 수변산책로 코스.png',NULL,NULL),(13,2,'무등산','광주 북구 금곡동','LO02','a3f7304e-6ea4-4d91-be71-583af19ba71e_무등산_주상절리대_복사.jpg',NULL,NULL),(14,4,'거제해금강','거제시 남부면 갈곶리 산1번지','LO02','6598ca14-590e-45b9-ac97-fb398335bee3_거제해금강.jpg',NULL,NULL),(15,4,'외도 보타니아','거제시 일운면 외도길 17','LO02','8b8332d0-e10a-4b6f-b719-ad663ce2f8bb_외도보타니아.jpg',NULL,NULL),(16,2,'광주 국립 광주 박물관','광주 북구 하서로 110','LO02','fd2f2fce-769d-41cd-8128-d0635aa62ad8_광주_국립광주박물관.jpg',NULL,NULL),(17,4,'고궁식육식당','경상남도 거제시 사등면 두동로 162-20','LO01','b3be1bf5-315b-4b91-bc90-588579d02fb4_고궁식육식당.png',NULL,NULL),(18,2,'홀리데이인 광주호텔','광주 서구 상무누리로 55 Holiday Inn Gwangju','LO03','04806c78-4318-47de-b8e9-2c0fe549d808_홀리데이인 광주호텔.jpg',NULL,NULL),(19,2,'유탑부티크호텔&레지던스','광주 서구 시청로 53','LO03','6545ef67-f35b-487e-b1f4-b00cce8fd984_유탑부티크호텔&레지던스.jpg',NULL,NULL),(20,5,'부평깡통시장','부산 중구 부평1길 48','LO01','dfdcde86-947a-474e-be9c-cfe4d043b3e7_부평깡통시장.jpg',NULL,NULL),(21,5,'해운대수목원','부산 해운대구 석대동 77','LO02','cfd2b872-4ff7-49ec-828b-6675d1e6de90_해운대수목원.jpg',NULL,NULL),(22,2,'라마다플라자 광주호텔','광주 서구 상무자유로 149','LO03','21bc6296-42a1-4153-8496-a9e6bf420b1d_라마다플라자 광주호텔.jpg',NULL,NULL),(23,6,'경복궁','서울 종로구 사직로 161 경복궁','LO02','fed079eb-a4b4-4b2e-9df2-f37a7944fbf9_경복궁.jpg',NULL,NULL),(24,6,'덕수궁','서울 중구 세종대로 99 덕수궁','LO02','bbb7e88d-d07c-4be9-ae3e-73947cbcb535_덕수궁.jpg',NULL,NULL),(25,2,'국립아시아문화전당하늘마당','광주 동구 광산동 113','LO02','450397cf-72e9-46f7-95f5-8f9e4c6a036c_lawn-g819842e21_1920.jpg',NULL,NULL),(26,6,'창덕궁','서울 종로구 율곡로 99','LO02','8f2c305b-6403-47aa-857c-b8aace513278_창덕궁.jpg',NULL,NULL),(27,2,'뒹굴동굴','광주 남구 천변좌로 410','LO02','9dacb918-b3dc-467a-8a66-11a757ed45de_뒹굴동굴.jpg',NULL,NULL),(28,2,'스치울때','광주 북구 면앙로6번길 49','LO01','87530cad-5562-4f8d-aa4b-695a2361eaa0_스치울때.jpeg',NULL,NULL);
/*!40000 ALTER TABLE `recommend` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-16 16:04:21
