-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8c207.p.ssafy.io    Database: gaza
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `id` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `email` varchar(20) NOT NULL,
  `email_domain` varchar(20) NOT NULL,
  `state_code` varchar(10) DEFAULT 'US2',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'관리자','010-0000-0000','admin','$2a$12$T79LTNr8MXcP14.L.TL42OoFx4ytlUrPAD2hc9szEIRYw3QBsCwLO','man','1987-10-02',NULL,'admin','google.com','US4'),(2,'이재훈','1234-8975-1235','user1','$2a$10$E/McJZjwfhB1HRuxes4Gu.vy.w7zB7eV6TDd0rC8ou/oupdYplEJq','man','1995-09-12','80ffba1c-d02f-42a6-b0ca-44b0cdc62dde_png-transparent-computer-icons-black-open-person-person-shape-rectangle-black-silhouette-thumbnail.png','qwer1234','naver.com','US2'),(3,'김석필','1234-1234-1325','guide5','$2a$10$9Wtmb5Yc1P8BnFjJL06fcOgqx12Q1IpT6YI63fJNaCjwAQXtntBiS','man','1990-10-10','758350a2-e976-454f-a68c-bbb099537d36_png-transparent-computer-icons-black-open-person-person-shape-rectangle-black-silhouette-thumbnail.png','guide5','ssafy.com','US1'),(4,'홍길동','010-1234-1234','guide1','$2a$10$12W/JiCpR0FpS4AK5mT58.G6oKMCsHyWp26j1cJyZQ.EVsSVc7OZ2','woman','1988-03-02','c77e1905-0faf-4e33-a756-90af10929949_guide1.png','guide1','gaza.com','US1'),(5,'AnnaPrincess','1234-1234-1234','guide6','$2a$10$1nOw7a4W3uh0cH6KSTnKG.uYRFaZlE.xIu/Q1y2LmMI7WRqv.T9JC','woman','1990-10-10','7511c493-10f0-4ac7-a052-2fb8d16ee7c8_princess-anna-1-6004802__340.webp','guide6','ssafy.com','US1'),(6,'김지성','010-1234-1234','guide2','$2a$10$qfZa64YdzTrnMNu/ANTXDOhYfWWNAEBYU82gwowjDTuGJJDh1wX5S','man','1977-12-03','ae4208bb-55dc-4b00-a9e3-183413de3eb4_guide2.png','guide2','gaza.com','US1'),(7,'김태희','010-4141-5151','guide7','$2a$10$iBytjmG96A9UCFTNflZFLegmswvX7otYitpO7BKluuK/NRBIYRV0.','woman','2000-06-19','6722d741-7028-4d79-ba83-ae50b57b99ff_사람.jpg','guide7','naver.com','US1'),(8,'SAKURA','010-9191-1531','guide3','$2a$10$5LyntmHX3wdu.lNAXfS7uetFLfQKkeF5/VRS8OlP7oBp50yI4sMlO','woman','1999-06-03','e8201284-c217-4912-b3fb-e3b016ff34df_사람2.jpg','guide3','daum.net','US1'),(9,'김채원','010-1111-1111','user2','$2a$10$lvhwiAsn5NOw.iPqS6jpmuXEEHaJrTKnV6u5k9rWfkbBn7vk5IEpO','woman','2000-08-01','2e9a1c02-6758-4e09-9507-45d0c6e14ef9_김채원.jpg','user','user.com','US2'),(10,'카즈하','010-0000-0000','user3','$2a$10$5DrJAbn7TzZ8zeXNUJaCJupgvwgObMJxz4ert7o2z3tcNa41bdXpe','woman','2003-08-09','2fbd0449-33c8-47e1-b30f-e45198f4deb9_카즈하.jpg','user3','gaza.com','US2'),(11,'Jake','010-0000-0000','user4','$2a$10$IYcqVwME21p6IspkQjaE7u4xXj1b8LJnWN2zLrwMs4pvmolVPa9J6','man','2002-11-15','420b10f0-a455-4061-96c5-ac3f3ba193d9_제이크.jpg','user4','gaza.com','US2'),(12,'홍길동','010-1234-1245','user5','$2a$10$cxeuk.f.9AyzjQo9oJnNyODJD5mkjd/wxZYucV1W54VaTIOHFftMS','man','1999-02-03','037022d9-9882-49c0-b4b1-6f5f995dd4c1_guide1.png','user5','gaza.com','US5');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-16 16:04:18
