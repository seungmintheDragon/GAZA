-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8c207.p.ssafy.io    Database: gaza
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `reservation_id` int NOT NULL AUTO_INCREMENT,
  `guide_id` int NOT NULL,
  `user_id` int NOT NULL,
  `state_code` varchar(10) DEFAULT NULL,
  `reservation_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `consulting_date` datetime NOT NULL,
  `travel_start_date` datetime NOT NULL,
  `travel_end_date` datetime NOT NULL,
  `number_of_people` int NOT NULL,
  `with_children` tinyint DEFAULT '0',
  `with_elderly` tinyint DEFAULT '0',
  `with_disabled` tinyint DEFAULT '0',
  `note` varchar(255) DEFAULT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`reservation_id`),
  KEY `FK_guide_TO_reservation_1` (`guide_id`),
  KEY `FK_user_TO_reservation_1` (`user_id`),
  CONSTRAINT `FK_guide_TO_reservation_1` FOREIGN KEY (`guide_id`) REFERENCES `guide` (`guide_id`),
  CONSTRAINT `FK_user_TO_reservation_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (16,2,2,'RE04','2023-02-16 01:58:15','2023-02-16 11:00:00','2023-02-23 18:00:00','2023-02-28 18:00:00',1,0,0,1,'알레르기 있습니다.','c7400ee6-387e-4264-8d39-b57237efa902'),(17,2,2,'RE04','2023-02-16 02:21:52','2023-02-16 12:00:00','2023-02-22 17:00:00','2023-03-11 20:00:00',1,1,0,0,'알레르기 있어요','0a01c0ab-1b64-402e-9286-e7b02fd9137c'),(18,2,2,'RE01','2023-02-16 02:31:06','2023-02-16 12:00:00','2023-02-21 02:00:00','2023-02-22 13:00:00',1,0,0,1,'알레르기 이써용\n','e477ca30-a0c1-4688-8f2f-0aae29730e95'),(19,2,2,'RE04','2023-02-16 04:38:05','2023-02-16 14:00:00','2023-02-22 15:00:00','2023-02-24 19:00:00',1,1,0,0,'알레르기 있습니다.','6b0ff575-a30d-4cc0-97c1-94cf5bbf6e82'),(20,2,2,'RE02','2023-02-16 04:57:36','2023-02-16 14:00:00','2023-02-17 08:00:00','2023-02-23 12:00:00',1,1,0,0,'알레르기 있으용',NULL);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-16 16:04:20
