-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8c207.p.ssafy.io    Database: gaza
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `travel_route`
--

DROP TABLE IF EXISTS `travel_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_route` (
  `travel_route_id` int NOT NULL AUTO_INCREMENT,
  `reservation_id` int NOT NULL,
  `latitude` decimal(10,0) NOT NULL,
  `longitude` decimal(10,0) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `order_no` int NOT NULL,
  PRIMARY KEY (`travel_route_id`),
  KEY `FK_reservation_TO_travel_route_1` (`reservation_id`),
  CONSTRAINT `FK_reservation_TO_travel_route_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`reservation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_route`
--

LOCK TABLES `travel_route` WRITE;
/*!40000 ALTER TABLE `travel_route` DISABLE KEYS */;
INSERT INTO `travel_route` VALUES (50,16,35,127,'국립아시아문화전당하늘마당','광주 동구 광산동 113',1),(51,16,35,127,'마네키','광주 동구 장동 67-2',2),(52,16,35,127,'솔밭솥밥','광주 동구 장동 57-1',3),(53,16,35,127,'솔밭솥밥','광주 동구 장동 57-1',4),(54,16,35,127,'포카포카','광주 동구 동명동 200-156',5),(55,17,35,127,'새벽달 본점','광주 동구 장동 86-7',1),(56,17,35,127,'카페호시정','광주 동구 동명동 154-17',2),(57,17,35,127,'광주 동구 동명동 154-55','광주 동구 동명동 154-55',3),(58,17,35,127,'마요네즈 광주동명점','광주 동구 동명동 72-47',4),(59,17,35,127,'한옥체험시설 여로 동명점','광주 동구 동명동 183-18',5),(60,18,35,127,'5.18민주광장','광주 동구 금남로1가 41',1),(61,18,35,127,'국립아시아문화전당하늘마당','광주 동구 충장로5가 122',2),(62,18,35,127,'스타벅스 광주지산DT점','광주 동구 동명동 12-3',3),(63,18,35,127,'광주 동구 동명동 197-9','광주 동구 동명동 197-9',4),(64,19,35,127,'광주 동구 학동 55-32','광주 동구 학동 55-32',1),(65,19,35,127,'광주 동구 학동 55-143','광주 동구 학동 55-143',2),(66,19,35,127,'광주 동구 학동 55-143','광주 동구 학동 55-143',3),(67,19,35,127,'전남대학교병원','광주 동구 학동 8',4),(68,19,35,127,'뒹굴동굴','광주 남구 사동 177-9',5);
/*!40000 ALTER TABLE `travel_route` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-16 16:04:22
